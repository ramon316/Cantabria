<template>
    <input 
        class="btn btn-danger d-block w-100" 
        type="submit" 
        value="Eliminar">
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
