/**Solo seleccionar un valor de los precios o regalos */

/**Si selecciona banquetes que force a poner un numero  */