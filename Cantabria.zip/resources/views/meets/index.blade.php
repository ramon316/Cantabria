@extends('adminlte::page')

@section('title', 'Reuniones')

@section('content_header')
<h1 class="text-center">Listado de Reuniónes</h1>
@stop

@section('content')
    @livewire('create-meet')
@stop

@section('css')
@stop

@section('js')
@stop
