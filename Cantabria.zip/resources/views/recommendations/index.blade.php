@extends('adminlte::page')

@section('title', 'Recomendaciones')

@section('content_header')
    <h1 class="text-center">Recomendaciones</h1>
@stop

@section('content')
@livewire('recommendations')
@stop

@section('css')

@stop

@section('js')


@stop