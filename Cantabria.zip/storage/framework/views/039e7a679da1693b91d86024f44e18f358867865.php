<div>
    <div class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-10">
                    <input
                    type="search"
                    wire:model="search"
                    class="form-control"
                    placeholder="Ingresa el nombre o correo de un cliente">
                </div>
                <div class="col-2">
                    <a class="btn btn-primary" href=" <?php echo e(route('clientes.create')); ?>">Nuevo Cliente</a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Teléfono</th>
                        <th>Correo</th>
                        <th>Opciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($cliente->nombre); ?></td>
                            <td><?php echo e($cliente->telefono); ?></td>
                            <td><?php echo e($cliente->email); ?></td>
                            <td width ="10px">
                                <a class="btn btn-primary" href="<?php echo e(route('clientes.edit',['cliente'=>$cliente->id])); ?>">Editar</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="card-footer">
            <?php echo e($clientes->links()); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\Cantabria\resources\views/livewire/clientes-index.blade.php ENDPATH**/ ?>