

<?php $__env->startSection('title', 'Cotización'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="container-fluid">
    <div class="row m-3 ">
      <div class="col-md-1">
        <a  class="btn btn-success" href="<?php echo e(route('cotizacion.index')); ?>">Regresar</a>
      </div>
      <div class="col-md-11">
        <h1 class="text-center">Genera tu cotización</h1>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('create-quoter')->html();
} elseif ($_instance->childHasBeenRendered('MBqSGd2')) {
    $componentId = $_instance->getRenderedChildComponentId('MBqSGd2');
    $componentTag = $_instance->getRenderedChildComponentTagName('MBqSGd2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('MBqSGd2');
} else {
    $response = \Livewire\Livewire::mount('create-quoter');
    $html = $response->html();
    $_instance->logRenderedChild('MBqSGd2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/cotizacion/create.blade.php ENDPATH**/ ?>