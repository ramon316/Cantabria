<!--Plantilla AdminLTE-->


<?php $__env->startSection('title', 'Usuarios'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="container">
    <h1 class="text-center">Lista de usuarios</h1>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('usuarios-index')->html();
} elseif ($_instance->childHasBeenRendered('rtkRbiy')) {
    $componentId = $_instance->getRenderedChildComponentId('rtkRbiy');
    $componentTag = $_instance->getRenderedChildComponentTagName('rtkRbiy');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rtkRbiy');
} else {
    $response = \Livewire\Livewire::mount('usuarios-index');
    $html = $response->html();
    $_instance->logRenderedChild('rtkRbiy', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<link rel="stylesheet" href="/css/app.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/usuarios/index.blade.php ENDPATH**/ ?>