<div>
    <div class="card">
        <div class="card-header">
            <h3>Bases</h3>
            <div class="row">
                <div class="col-3">
                    <select class="form-control" wire:model="type">
                        <option value="">--Seleccciona un tipo de mesa--</option>
                       <?php $__currentLoopData = $tabletypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($tipo->tabletype); ?>"><?php echo e($tipo->tabletype); ?></option>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="p-2 mt-2 text-xs text-danger">
                        <?php echo e($message); ?>

                    </div>                     
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-3">
                    <select class="form-control" wire:model="color">
                    <?php if($tablecolors->count() == 0): ?>
                        <option>--Selecciona un color primero--</option>
                    <?php else: ?>
                        <option value="">--Selecciona un color--</option>
                        <?php $__currentLoopData = $tablecolors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tablecolor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tablecolor->color); ?>"><?php echo e($tablecolor->color); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </select>
                    <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="p-2 mt-2 text-xs text-danger">
                        <?php echo e($message); ?>

                    </div>                     
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-2">
                    <input class="form-control" type="number" placeholder="Cantidad de manteles" wire:model='amount'>
                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="p-2 mt-2 text-xs text-danger">
                        <?php echo e($message); ?>

                    </div>                     
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-2 w-full">
                    <button class="btn btn-primary" wire:click='addTableclothbase'>Agregar</button>
                </div>
            </div>
        </div>
        <div class="card-body">
            <?php if($evento->tableclothbase->count()>=1): ?>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Tipo mesa</th>
                        <th>Color</th>
                        <th>Cantidad</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $evento->tableclothbase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tableclothbase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($tableclothbase->tabletype); ?></td>
                            <td><?php echo e($tableclothbase->color); ?></td>
                            <td><?php echo e($tableclothbase->pivot->amount); ?></td>
                            <td><a class="btn btn-danger" wire:click="deleteTableclothbase(<?php echo e($tableclothbase); ?>)">Eliminar</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php else: ?>
            Este evento aun no cuenta con bases de mantel registrados.
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\Cantabria\resources\views/livewire/add-tableclothbase.blade.php ENDPATH**/ ?>