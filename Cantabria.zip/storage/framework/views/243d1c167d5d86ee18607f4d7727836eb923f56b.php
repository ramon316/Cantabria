

<?php $__env->startSection('title', 'Otros Servicios'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="container">
    <h1 class="text-center">Agregar otros servicios</h1>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="app">

<form method="POST" action="<?php echo e(route('servicio.store')); ?>" novalidate>    
    <?php echo csrf_field(); ?>
    <div class="row">

            
      <div class="col-md-5">
        <div class="form-group">
          <label for="nombre">Nombre:</label>
          <input type="text" class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nombre" id="nombre" aria-describedby="helpNombre" placeholder=""
          value="<?php echo e(old('nombre')); ?>">
          <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback d-block" role="alert"> <?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <small id="helpNombre" class="form-text text-muted">Ingresa el nombre que lo identificará</small>
        </div>
      </div>
      

      
      <div class="col-md-3">
        <div class="form-group">
          <label for="">Días del servicio</label>
            <select class="form-control <?php $__errorArgs = ['dias'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                    name="dias" 
                    value="<?php echo e(old('dias')); ?>">
              <option value="">--Selecciona los días--</option>
              <?php $__currentLoopData = $dias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($dia['id']); ?>"><?php echo e($dia['dias']); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <small id="helpNombre" class="form-text text-muted">Selecciona los día en el que es efectivo el servicio</small>
        </div>
      </div>
      

      
      <div class="col-md-3">
        <div class="form-group">
          <label for="año">Año:</label>
          <select class="form-control <?php $__errorArgs = ['año'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                    name="año" 
                    value="<?php echo e(old('año')); ?>">
              <option value="">--Selecciona el año--</option>
              <?php $__currentLoopData = $años; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $año): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($año); ?>"><?php echo e($año); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          <small id="helpaño" class="form-text text-muted">Selecciona el año en el que es efectivo el servicio</small>
        </div>
      </div>
      
    </div>

    <div class="row">
      <div class="col-md-3">
        <div class="form-group">
          <label for="costo">Costo en pesos:</label>
          <input type="number" class="form-control <?php $__errorArgs = ['costo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="costo" id="costo"
          value="<?php echo e(old('costo')); ?>">
          <?php $__errorArgs = ['costo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback d-block" role="alert"> <?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <small id="helpNombre" class="form-text text-muted">Ingresa el costo del servicio</small>
        </div>
      </div>

     
      <div class="col-md-3">
        <div class="form-group">
          <label for="invitados">Cantidad de invitados:</label>
          <input type="number" class="form-control <?php $__errorArgs = ['invitados'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="invitados" id="invitados"
          value="<?php echo e(old('invitados')); ?>">
          <?php $__errorArgs = ['invitados'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback d-block" role="alert"> <?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <small id="helpmedida" class="form-text text-muted">Ingresa la cantidad de invitados para el que aplicara esta decoración, si es para todo tipo ingresa un cero</small>
        </div>
      </div>
    </div>
    <div class="form-group">
      <input type="hidden" name="servicio" value="otroservicio">
    </div>
    
    <input type="submit" class="btn btn-primary" alig value="Guardar">
    

</form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/servicios/otroservicio/create.blade.php ENDPATH**/ ?>