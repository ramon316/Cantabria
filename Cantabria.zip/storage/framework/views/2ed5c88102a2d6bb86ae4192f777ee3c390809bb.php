

<?php $__env->startSection('title', 'Cotizaciones'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="container-fluid">
    <div class="row m-3 ">
      <div class="col-md-1">
        <a  class="btn btn-success" href="<?php echo e(route('cotizacion.show', ['cotizacion'=>$cotizacion->id])); ?>">Regresar</a>
      </div>
      <div class="col-md-11">
        <h1 class="text-center">Agregar servicio</h1>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <!--Esta es el apartado de los mensajes-->
        <?php if(session('mensaje')): ?>
        <div class="alert <?php echo e(session('estilo')); ?> alert-dismissible fade show" role="alert">
        <strong><?php echo e(session('mensaje')); ?></strong> 
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>
        <?php endif; ?>
        <div class="row justify-content-around">
            <div class="col-md-5 bg-white shadow p-4 mb-5 ml-5 rounded">
                <h4>Información del cliente</h4>
                <p><strong>Cliente: </strong><?php echo e($cotizacion->cliente->nombre); ?></p>
                <p><strong>Teléfino: </strong><?php echo e($cotizacion->cliente->telefono); ?></p>
                <p><strong>Email: </strong><?php echo e($cotizacion->cliente->email); ?></p>
                <p><strong>Dirección: </strong>C. <?php echo e($cotizacion->cliente->calle); ?> #<?php echo e($cotizacion->cliente->numero); ?> Col.<?php echo e($cotizacion->cliente->colonia); ?> C.P. <?php echo e($cotizacion->cliente->cp); ?></p>
            </div>
            <div class="col-md-5 bg-white shadow p-3 mb-5 ml-5 rounded">
                <h4>Información de la cotizacion</h4>
                <p><strong>Tipo: </strong><?php echo e($cotizacion->title); ?></p>
                <p><strong>Horas: </strong><?php echo e($cotizacion->horas); ?> horas</p>
                <p><strong>Fecha: </strong><?php echo e($cotizacion->start->format('d-m-Y')); ?></p>
                <p><strong>Invitados: </strong><?php echo e($cotizacion->invitados); ?></p>
                <p><strong>Precio: </strong> $<?php echo number_format($costoCotizacion); ?> pesos</p>
            </div>
            <?php if(count($cotizacion->servicio)>0): ?>
            <div class="col-md-5 bg-white shadow p-3 mb-5 ml-5 rounded">
              <div class="card">
                <div class="card-body">
                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th>Servicio</th>
                        <th>Cantidad</th>
                        <th>Eliminar</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $serviciosCotizacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicioCotizacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($servicioCotizacion->nombre); ?></td>
                        <td><?php echo e($servicioCotizacion->pivot->cantidad); ?></td>
                        <td>
                          <form method="POST" action=" <?php echo e(route('cotizacionservicio.destroy', ['servicio' => $servicioCotizacion->id, 'cotizacion'=>$cotizacion->id])); ?>">
                            <?php echo method_field("delete"); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" 
                            class="btn btn-danger">Eliminar</button>
                          </form>
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <?php endif; ?>
        </div>
<form method="POST" action="<?php echo e(route('cotizacionservicio.store')); ?>" novalidate>
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                  <label for="servicio">Selecciona el servicio a agregar:</label>
                  <select class="form-control
                  <?php $__errorArgs = ['servicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    is-invalid
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                          value = "<?php echo e(old('servicio')); ?>" 
                          name="servicio" 
                          id="servicio"
                      >
                    <option value="">--Selecciona un servicio--</option>
                  <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value=<?php echo e($servicio->id); ?>><?php echo e($servicio->nombre); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <?php $__errorArgs = ['servicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback d-block" role="alert"> <?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <small id="helpNombre" class="form-text text-muted">Selecciona el servicio que deseas agregar al avento</small>
              </div>
            </div>
           <div class="col-md-4">
              <div class="form-group">
                <label>Cantidad del servicio:</label>
                  <input type="number"
                    class="form-control
                    <?php $__errorArgs = ['cantidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      is-invalid
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    name="cantidad"
                    id="cantidad"
                    value=<?php echo e(old('cantidad')); ?>>
                    <?php $__errorArgs = ['cantidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="invalid-feedback d-block" role="alert"> <?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <small id="helpId" class="form-text text-muted">Ingresa la cantidad en valor numérico de la cantidad de servicios o platillos que necesitas.</small>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="regalo">Es un servicio de regalo:</label>
                  <select class="form-control"
                          value = "<?php echo e(old('regalo')); ?>" 
                          name="regalo" 
                          id="regalo"
                      >
                  <option value="">--Selecciona una opción--</option>
                  <option value="0">No</option>
                  <option value="1">Si</option>
                  </select>
                  <small id="helpNombre" class="form-text text-muted">Selecciona un "SI", si este servicio no se cobrará al cliente</small>
              </div>
            </div>

            <div class="form-group">
              <input type="hidden" id="cotizacion" name="cotizacion" value="<?php echo e($cotizacion->id); ?>">
            </div>
        </div>

      <div class="row">
          <div class="form-group">
              <input type="submit" class="btn btn-primary" value="Guardar">
          </div>
      </div>
    </form>

    <div class="row">
      <table>
        
      </table>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="/css/app.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/cotizacionservicio/create.blade.php ENDPATH**/ ?>