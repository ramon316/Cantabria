

<?php $__env->startSection('title', 'Clientes'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="text-center">Clientes</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('clientes-index')->html();
} elseif ($_instance->childHasBeenRendered('ZnZigi0')) {
    $componentId = $_instance->getRenderedChildComponentId('ZnZigi0');
    $componentTag = $_instance->getRenderedChildComponentTagName('ZnZigi0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ZnZigi0');
} else {
    $response = \Livewire\Livewire::mount('clientes-index');
    $html = $response->html();
    $_instance->logRenderedChild('ZnZigi0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="/css/bootstrap.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/clientes/index.blade.php ENDPATH**/ ?>