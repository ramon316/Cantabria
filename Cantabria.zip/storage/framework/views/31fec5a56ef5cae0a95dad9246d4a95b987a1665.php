<div>
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <div class="card-title">Bases florales</div>
                <div class="card-tools">
                    <!-- Buttons, labels, and many other things can be placed here! -->
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3 mt-1">
                        <select class="form-control" wire:model="category">
                            <option value="">--Categoría--</option>
                            <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->category); ?>"><?php echo e($category->category); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="p-2 mt-2 text-xs text-danger">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-3 mt-1">
                        <select class="form-control" wire:model="name">
                            <option value="">--Nombres--</option>
                            <?php $__currentLoopData = $names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($name->name); ?>"><?php echo e($name->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="p-2 mt-2 text-xs text-danger">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-3 mt-1">
                        <input type="number" class="form-control" wire:model="amount" placeholder="Ingresa la cantidad">
                        <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="p-2 mt-2 text-xs text-danger">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-3">
                        <button class="btn btn-primary mt-1" wire:click="save">Agregar</button>
                    </div>
                </div>
                
                <?php if($banquetExist == true): ?>
                <div class="row">
                    <div class="col-md-3 mt-1">
                        <select class="form-control" wire:model="napkins">
                            <option value="">--Servilletas--</option>
                            <option value="Ivory">Ivory</option>
                            <option value="Negra">Negra</option>
                        </select>
                        <?php $__errorArgs = ['napkins'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="p-2 mt-2 text-xs text-danger">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-3 mt-1">
                        <select class="form-control" wire:model="plates">
                            <option value="">--Platos--</option>
                            <option value="Dorado">Dorado</option>
                            <option value="Plata">Plata</option>
                        </select>
                        <?php $__errorArgs = ['plates'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="p-2 mt-2 text-xs text-danger">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <div class="card-title">Bases florales registradas</div>
                <div class="card-tools">
                    <!-- Buttons, labels, and many other things can be placed here! -->
                </div>
            </div>
            <div class="card-body">
                <div class="table table-striped">
                    
                    <?php if($records->isEmpty() == false): ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Categoría</th>
                                <th>Nombre</th>
                                <th>Cantidad</th>
                                <th>Servilletas</th>
                                <th>Platos</th>
                                <th>Opciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($record->category); ?></td>
                                <td><?php echo e($record->name); ?></td>
                                <td><?php echo e($record->pivot->amount); ?></td>
                                <td><?php echo e($record->pivot->napkins); ?></td>
                                <td><?php echo e($record->pivot->plates); ?></td>
                                <td>
                                    <button class="btn btn-danger" wire:click="delete(<?php echo e($record->id); ?>)">Eliminar</button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    Aun no cuenta con registros asignados.
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\Cantabria\resources\views/livewire/add-evento-floralbase.blade.php ENDPATH**/ ?>