<?php $__env->startSection('title', 'Servicios'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="container">
    <h1 class="text-center">Lista de servicios</h1>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('services-index')->html();
} elseif ($_instance->childHasBeenRendered('4fewApZ')) {
    $componentId = $_instance->getRenderedChildComponentId('4fewApZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('4fewApZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4fewApZ');
} else {
    $response = \Livewire\Livewire::mount('services-index');
    $html = $response->html();
    $_instance->logRenderedChild('4fewApZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="/css/app.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/servicios/index.blade.php ENDPATH**/ ?>