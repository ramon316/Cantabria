

<?php $__env->startSection('title', 'Detalle banquete'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="container-fluid">
    <div class="row m-3 ">
        <div class="col-md-1">
            <a class="btn btn-success" href="<?php echo e(route('eventos.show',['evento'=>$evento->id])); ?>">Regresar</a>
        </div>
        <div class="col-md-11">
            <h1 class="text-center">Detalle del banquete</h1>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <label for="">Cliente: <?php echo e($evento->cliente->nombre); ?></label><br>
            <label for="">Evento: <?php echo e($evento->title); ?> - <?php echo e($evento->subtitle); ?></label><br>
            <label for="">Fecha del evento: <?php echo e($evento->start->format('d-m-Y')); ?></label><br>
            <label for="">Fecha de degustación:
                <?php if(isset($evento->banquet)): ?>
                <?php echo e($evento->banquet->updated_at->format('d-m-Y')); ?>

                <?php endif; ?>
            </label><br>
            <label for="">Cantidad de platillos:<?php echo e($cantidad); ?>

            </label><br>
        </div>

    </div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('banquet-index', ['evento' => $evento])->html();
} elseif ($_instance->childHasBeenRendered('q2o7gzs')) {
    $componentId = $_instance->getRenderedChildComponentId('q2o7gzs');
    $componentTag = $_instance->getRenderedChildComponentTagName('q2o7gzs');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('q2o7gzs');
} else {
    $response = \Livewire\Livewire::mount('banquet-index', ['evento' => $evento]);
    $html = $response->html();
    $_instance->logRenderedChild('q2o7gzs', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/banquets/create.blade.php ENDPATH**/ ?>