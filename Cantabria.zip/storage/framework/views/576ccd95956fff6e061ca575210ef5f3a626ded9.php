

<?php $__env->startSection('title', 'Cotización'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="text-center">Visualización de tus cotizaciones</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cotizacion-index')->html();
} elseif ($_instance->childHasBeenRendered('FRkwvDF')) {
    $componentId = $_instance->getRenderedChildComponentId('FRkwvDF');
    $componentTag = $_instance->getRenderedChildComponentTagName('FRkwvDF');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FRkwvDF');
} else {
    $response = \Livewire\Livewire::mount('cotizacion-index');
    $html = $response->html();
    $_instance->logRenderedChild('FRkwvDF', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/cotizacion/index.blade.php ENDPATH**/ ?>