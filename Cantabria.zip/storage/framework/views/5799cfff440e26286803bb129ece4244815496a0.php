<?php $__env->startSection('title', 'Perfil'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="text-center">Editar perfil</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <!--Esta es el apartado de los mensajes-->
    <?php if(session('mensaje')): ?>
    <div class="alert <?php echo e(session('estilo')); ?>" role="alert">
    <strong><?php echo e(session('mensaje')); ?></strong>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    </div>
    <?php endif; ?>
    
    <form method="POST" action="<?php echo e(route('perfils.update',['perfil' => $perfil->id])); ?>" enctype="multipart/form-data" novalidate>
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>

        <div class="form-group">
          <label for="nombre">Nombre:</label>
          <input type="text" name="nombre" id="nombre" class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> in-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" aria-describedby="helpId"
          value="<?php echo e(Auth::user()->name); ?>">
          <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback" role="alert"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <small id="helpId" class="text-muted">Ingresa tu nombre</small>
        </div>

        <div class="form-group">
            <label for="telefono">Teléfono</label>
            <input type="tel" name="telefono" id="telefono" class="form-control <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-describedby="helptelefono"
            value="<?php echo e($perfil->telefono); ?>">
            <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback" role="alert"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <small id="helptelefono" class="form-text text-muted">Ingresa tu telefono con clave lada, ejemplo, 6141234567</small>
        </div>

       <!--Agregar una imagen-->
            <div class="form-group">
                <label for="imagen">Elige una imagen</label>
                <input type="file"
                class="form-control <?php $__errorArgs = ['imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                name="imagen"
                id="imagen"
                value="<?php echo e(old('imagen')); ?>"
                >
                <small id="helpId" class="form-text text-muted">Selecciona la imagen que se usará para tu perfil</small>
                <!--Como estamos editando la imagen es necesario que la mostremos antes para poder saber si la cambiaremos-->
                <div class="mt-4">
                    <p>Imagen actual:</p>
                    <?php if(Auth::user()->perfil->imagen): ?>
                        

                        <img src="<?php echo e(asset($perfil->url_imagen)); ?>" alt="" width="300">
                    <?php else: ?>
                        <img src="<?php echo e(asset('upload-perfiles') . '/' . 'default.png'); ?>" style="width: 300px">
                    <?php endif; ?>
                </div>
                <?php $__errorArgs = ['imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        <input type="submit" class="btn btn-primary" alig value="Guardar">

    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<link rel="stylesheet" href="/css/app.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/perfils/edit.blade.php ENDPATH**/ ?>