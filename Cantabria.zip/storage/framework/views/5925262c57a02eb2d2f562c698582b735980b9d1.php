

<?php $__env->startSection('title', 'Cuentas'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="text-center">Cuentas</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="app">
<div class="container">
    <form method="POST" action="<?php echo e(route('cuentas.store')); ?>" novalidate>
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class ="col-md-4">
            <div class="form-group">
              <label for="banco">Banco</label>
              <input type="text" name="banco" id="banco" class="form-control 
              <?php $__errorArgs = ['banco'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  is-invalid
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" aria-describedby="helpId"
              value="<?php echo e(old('banco')); ?>">
              <?php $__errorArgs = ['banco'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback" role="alert"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <small id="helpId" class="text-muted">Ingresa el nombre del banco al que pertenece la cuentas</small>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
            <label for="cuenta">Nombre de la Cuenta</label>
            <input type="text" name="cuenta" id="cuenta"
            value="<?php echo e(old('cuenta')); ?>" 
            class="form-control 
            <?php $__errorArgs = ['cuenta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                is-invalid
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
            placeholder="" aria-describedby="helpId">
            <?php $__errorArgs = ['cuenta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback" role="alert"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <small id="helpId" class="text-muted">Ingresa el nombre de la cuenta con la que lo quieras identificar</small>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
            <label for="clabe">Clabe</label>
            <input type="text" name="clabe" id="clabe"
            value="<?php echo e(old('clabe')); ?>"
            class="form-control
            <?php $__errorArgs = ['clabe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                is-invalid
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
            placeholder="" aria-describedby="helpId">
            <?php $__errorArgs = ['clabe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback" role="alert"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <small id="helpId" class="text-muted">Ingresa el numero Clabe de la cuenta</small>
            </div>
        </div>
    </div>
        <div class="row">
            <div class="form-group">
              <label for="moneda">Moneda</label>
              <select class="form-control" name="moneda" id="moneda">
                <option value="pesos">Pesos</option>
                <option value="dolares">Dolares</option>
              </select>
            </div>
        </div>
        <div class="row">
            <div class="form-group">
              <input type="submit"
                class="btn btn-primary" value="Guardar">
            </div>
        </div>
    </form>
<div>


<div class="mx-auto bg-white p-3">  
<table class="table">
    <thead class="bg-primary text-light text-center">
        <tr>
            <th>Banco</th>
            <th>Cuentas</th>
            <th>Clabe</th>
            <th>Moneda</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="text-center">
            <td><?php echo e($cuenta->banco); ?></td>
            <td><?php echo e($cuenta->cuenta); ?></td>
            <td><?php echo e($cuenta->clabe); ?></td>
            <td><?php echo e($cuenta->moneda); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/cuentas/index.blade.php ENDPATH**/ ?>