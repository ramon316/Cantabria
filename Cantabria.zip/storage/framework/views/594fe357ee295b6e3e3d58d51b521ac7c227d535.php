

<?php $__env->startSection('title', 'Inventario manteles'); ?>

<?php $__env->startSection('plugins.Sweetalert2', true); ?>

<?php $__env->startSection('content_header'); ?>
<h1 class="text-center">Inventario de manteles</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('inventories.tablecloth-index')->html();
} elseif ($_instance->childHasBeenRendered('hsj9f7Z')) {
    $componentId = $_instance->getRenderedChildComponentId('hsj9f7Z');
    $componentTag = $_instance->getRenderedChildComponentTagName('hsj9f7Z');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hsj9f7Z');
} else {
    $response = \Livewire\Livewire::mount('inventories.tablecloth-index');
    $html = $response->html();
    $_instance->logRenderedChild('hsj9f7Z', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    Livewire.on('mostrarAlerta',tableclothId =>{
        Swal.fire({
            title: 'Estas seguro de eliminar el registro?',
            text: "No podrás recuperarlo",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Si, eliminalo!'
            })
            .then((result) => {
            if (result.value== true) {
                Swal.fire(
                    'Registro eliminado!',
                    Livewire.emit('delete', tableclothId)
                )
            }
        })
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/inventories/tablecloth.blade.php ENDPATH**/ ?>