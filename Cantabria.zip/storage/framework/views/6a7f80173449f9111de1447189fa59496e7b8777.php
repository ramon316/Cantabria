

<?php $__env->startSection('title', 'Eventos'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="row">
    <div class="col-md-8">
        <h1 class="text-center">Evento de <?php echo e($evento->cliente->nombre); ?></h1>
    </div>
    <div class="col-md-4">
        <div class="form-groupform-check">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('status-event', ['evento' => $evento])->html();
} elseif ($_instance->childHasBeenRendered($evento->id)) {
    $componentId = $_instance->getRenderedChildComponentId($evento->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($evento->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($evento->id);
} else {
    $response = \Livewire\Livewire::mount('status-event', ['evento' => $evento]);
    $html = $response->html();
    $_instance->logRenderedChild($evento->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="app">
    <div class="container">
        <div class="row justify-content-around">
            <div class="col-md-3 bg-white shadow p-4 mb-5 rounded">
                <h4>Información del cliente</h4>
                <strong>Cliente: </strong><?php echo e($evento->cliente->nombre); ?><br>
                <strong>Teléfino: </strong><?php echo e($evento->cliente->telefono); ?><br>
                <strong>Email: </strong><?php echo e($evento->cliente->email); ?><br>
                <strong>Dirección: </strong>C. <?php echo e($evento->cliente->calle); ?> #<?php echo e($evento->cliente->numero); ?><br>
                Col.<?php echo e($evento->cliente->colonia); ?> C.P. <?php echo e($evento->cliente->cp); ?><br>
            </div>
            <div class="col-md-3 bg-white shadow p-3 mb-5  rounded">
                <h4>Información del evento</h4>
                <strong>Tipo: </strong><?php echo e($evento->title); ?><br>
                <strong>Subtipo: </strong><?php echo e($evento->subtitle); ?><br>
                <strong>Horas: </strong><?php echo e($evento->horas); ?> horas<br>
                <strong>Fecha: </strong><?php echo e($evento->start->format('d-m-Y')); ?><br>
                <strong>Invitados: </strong><?php echo e($evento->invitados); ?><br>
                <strong>Precio evento: </strong>$<?php echo number_format($costoEvento); ?> pesos<br>
                <?php if($abonoEvento <> 0): ?>
                    <strong>Abonos:</strong> $<?php echo number_format($abonoEvento); ?> pesos<br>
                    <?php endif; ?>
                    <?php if($diferenciaEvento <> 0 ): ?>
                        <strong>Restante:</strong> $<?php echo number_format($diferenciaEvento); ?> pesos<br>
                        <?php endif; ?>
                        <?php if($discount<>0): ?>
                            <strong>Descuento:</strong>$<?php echo number_format($discount); ?> pesos<br>
                            <strong>Total a pagar:</strong>$<?php echo number_format($total); ?> pesos<br>
                            <?php endif; ?>
            </div>
            <div class="col-md-3 bg-white shadow p-3 mb-5  rounded">
                <h4>Check List</h4>

                <button type="button" class="btn
                <?php if(empty($evento->Checklist->contrato)): ?>
                btn-secondary
                <?php else: ?>
                btn-info
                <?php endif; ?>
                d-block w-100 inline mb-2">Contrato
                </button>

                <button type="button" class="btn
                <?php if(empty($evento->Checklist->ademdum)): ?>
                btn-secondary
                <?php else: ?>
                btn-info
                <?php endif; ?>
                d-block w-100 inline mb-2">Ademdum
                </button>

                <button type="button" class="btn
                <?php if($evento->tablecloth()->count() > 0): ?>)
                btn-info
                <?php else: ?>
                btn-secondary
                <?php endif; ?>
                d-block w-100 inline mb-2">Mantelería
                </button>

                <button class="btn
                <?php if($evento->floralbase()->count() > 0): ?>
                    btn-info
                <?php else: ?>
                    btn-secondary
                <?php endif; ?>
                d-block w-100 inline mb-2" href="<?php echo e(route('basefloral.create',['evento'=>$evento->id])); ?>"
                    role="button">Bases florales</button>


                <button type="button" class="btn
                <?php if(empty($evento->Checklist->degustacion)): ?>
                btn-secondary
                <?php else: ?>
                btn-info
                <?php endif; ?>
                d-block w-100 inline mb-2">Degustación
                </button>

                
                <?php if($banquetExist == true): ?>
                <button type="button" class="btn
                    <?php if($evento->banquet()->count() > 0): ?>
                    btn-info
                    <?php else: ?>
                    btn-secondary
                    <?php endif; ?>
                d-block w-100 inline mb-2">Banquete
                </button>
                <?php endif; ?>


            </div>
        </div>

        
        <div class="row justify-content-around">
            <div class="col-md-3 bg-white shadow p-4 mb-5 rounded">
                <h4 class="text-center">Acciones</h4>

                <a href="" class="btn
                <?php if(empty($evento->layout)): ?>
                    btn-danger
                <?php else: ?>
                    btn-info
                <?php endif; ?>
                d-block w-100 inline mb-2" role="button" data-controls-modal="exampleModal" data-toggle="modal"
                    data-target="#exampleModal" data-bs-backdrop="static" data-bs-keyboard="false">Layout
                </a>


                <a class="btn btn-info d-block w-100 inline mb-2"
                    href="<?php echo e(route('eventos.pago',['evento'=>$evento->id])); ?>" role="button">Generar Pago</a>


                <a class="btn
                <?php if($discount <> 0): ?>
                    btn-info
                <?php else: ?>
                    btn-danger
                <?php endif; ?>
                d-block w-100 inline mb-2" href=" <?php echo e(route('discounts.create',['evento' => $evento->id])); ?> "
                    role="button">Agregar descuento
                </a>


                <a class="btn btn-info d-block w-100 inline mb-2"
                    href="<?php echo e(route('eventoservicios.create',['evento'=>$evento])); ?>" role="button">Agregar o eliminar
                    Servicio</a>

                <?php if(count($evento->tablecloth) >0): ?>
                <a class="btn btn-info d-block w-100 inline mb-2"
                    href="<?php echo e(route('manteleria.create',['evento'=>$evento->id])); ?>" role="button">Manteleria y
                    sillas</a>
                <?php else: ?>
                <a class="btn btn-danger d-block w-100 inline mb-2"
                    href="<?php echo e(route('manteleria.create',['evento'=>$evento->id])); ?>" role="button">Manteleria y
                    sillas</a>
                <?php endif; ?>

                
                <a class="btn
                <?php if($evento->floralbase()->count() > 0): ?>
                    btn-info
                <?php else: ?>
                    btn-danger
                <?php endif; ?>
                d-block w-100 inline mb-2" href="<?php echo e(route('basefloral.create',['evento'=>$evento->id])); ?>"
                    role="button">Bases florales</a>

                <?php if($monto >= 15000 && $admin): ?>
                <a class="btn btn-info d-block w-100 inline mb-2"
                    href="<?php echo e(route('eventos.contrato',['evento'=>$evento->id])); ?>" role="button">Generar Contrato</a>
                <?php endif; ?>

                
                <?php if($banquetExist == true): ?>
                <a class="btn
                <?php if($evento->banquet()->count()>0): ?>
                    btn-info
                <?php else: ?>
                    btn-danger
                <?php endif; ?>
                d-block w-100 inline mb-2" href="<?php echo e(route('banquetes.create', ['evento'=>$evento->id])); ?>"
                    role="button">Agregar banquete
                </a>
                <?php endif; ?>

            </div>

            <?php if(count($evento->servicio)): ?>
            <div class="col-md-3 bg-white shadow p-3 mb-5 rounded text-center">
                
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Cantidad</th>
                            <th>Costo</th>
                            <th>Cortesía</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $evento->servicio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($servicio->nombre); ?></td>
                            <td><?php echo e($servicio->pivot->cantidad); ?></td>
                            <td>$<?php echo number_format($servicio->pivot->costo); ?></td>
                            <td><?php if($servicio->pivot->regalo == 1): ?>
                                Si
                                <?php else: ?>
                                No
                                <?php endif; ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
            <?php if(count($pagos)): ?>
            <div class="col-md-3 bg-white shadow p-3 mb-5 rounded text-center">
                
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Monto</th>
                            <th>Tipo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($pago->created_at->format('d-m-Y')); ?></td>
                            <td><?php echo e($pago->tipo); ?></td>
                            <td>$<?php echo number_format($pago->monto); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php endif; ?>
        </div>

        

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('comments-index', ['evento' => $evento])->html();
} elseif ($_instance->childHasBeenRendered('91fbgAv')) {
    $componentId = $_instance->getRenderedChildComponentId('91fbgAv');
    $componentTag = $_instance->getRenderedChildComponentTagName('91fbgAv');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('91fbgAv');
} else {
    $response = \Livewire\Livewire::mount('comments-index', ['evento' => $evento]);
    $html = $response->html();
    $_instance->logRenderedChild('91fbgAv', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        
    </div>
</div>
<div class="modal fade bd-example-modal-lg" data-backdrop="static" data-keyboard="false" id="exampleModal" tabindex="-1"
    role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" wire:ignore.self>
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Layout del evento</h5>
            </div>
            <div class="modal-body">
                <?php if(empty($evento->layout)): ?>
                <p>Aun no cuenta con layout, si gustas puedes subir uno a continuación</p>
                <?php else: ?>
                <img src="<?php echo e(Storage::url($evento->layout)); ?>" class="img-fluid" alt="">
                <p>Si deseas puedes actualizar la imagen.</p>
                <?php endif; ?>
                <form action="<?php echo e(route('eventos.layout',['evento'   =>  $evento->id])); ?>" method="post"
                    enctype="multipart/form-data" novalidate>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="file" name="layout" id="layout">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal" wire:click='close'>Cerrar</button>
                <button type="submit" class="btn btn-primary">Guardar</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/eventos/show.blade.php ENDPATH**/ ?>