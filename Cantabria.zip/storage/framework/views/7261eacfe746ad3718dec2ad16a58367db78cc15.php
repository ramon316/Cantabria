<div>
    <div class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-10">
                    <input
                        type="search"
                        wire:model="search"
                        class="form-control"
                        placeholder="Ingresa el nombre o el correo del usuario">
                </div>
                <div class="col-2">
                    <a class="btn btn-primary" href=" <?php echo e(route('usuarios.create')); ?> ">Nuevo usuario</a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Correo</th>
                        <th>Categoría</th>
                        <th>Opciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($usuario->name); ?></td>
                        <td><?php echo e($usuario->email); ?></td>
                        <td><?php if($usuario->hasRole('Administrador')): ?>
                                Administrador
                            <?php elseif($usuario->hasRole('Usuario')): ?>
                                Usuario
                            <?php else: ?>
                                Sin Rol
                            <?php endif; ?>
                        </td>
                        <td width="10px">
                            <a class="btn btn-primary" href="<?php echo e(route('usuarios.edit', ['usuario' =>$usuario->id])); ?>">Modificar</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer">
                <?php echo e($usuarios->links('pagination::bootstrap-4')); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\Cantabria\resources\views/livewire/usuarios-index.blade.php ENDPATH**/ ?>