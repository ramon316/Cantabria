

<?php $__env->startSection('title', 'Recomendaciones'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="text-center">Recomendaciones</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('recommendations')->html();
} elseif ($_instance->childHasBeenRendered('3OKGT0t')) {
    $componentId = $_instance->getRenderedChildComponentId('3OKGT0t');
    $componentTag = $_instance->getRenderedChildComponentTagName('3OKGT0t');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3OKGT0t');
} else {
    $response = \Livewire\Livewire::mount('recommendations');
    $html = $response->html();
    $_instance->logRenderedChild('3OKGT0t', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/recommendations/index.blade.php ENDPATH**/ ?>