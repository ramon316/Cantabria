

<?php $__env->startSection('title', 'Clientes'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="container">
    <h1 class="text-center">Eventos de <?php echo e($cliente->nombre); ?></h1>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <?php if(count($eventos)>0): ?>
            <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mr-4" style="width: 16rem;">
                    <img src="/image/cantabria (1).jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                    <h5 class="card-title"><?php echo e(strtoupper($evento->title)); ?></h5>
                    <p class="card-text">Evento para <?php echo e($evento->invitados); ?> personas, el día <?php echo e($evento->start->format('d-m-Y')); ?></p>
                    <a href="<?php echo e(route('eventos.show',['evento' => $evento->id])); ?>" class="btn btn-primary">Detalles</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
         <div class="h3">
            Por el momento no cuenta con eventos registrados.
            <div class="row">
                <a class="btn btn-primary" href="<?php echo e(route('clientes.index')); ?>">Regresar</a>
            </div>
         </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/clientes/eventos.blade.php ENDPATH**/ ?>