<div>
    <input type="checkbox" class="form-check-input" wire:model="status">
    <label class="form-check-label" for="exampleCheck1">Estatus del evento</label>
</div>
<?php /**PATH C:\laragon\www\Cantabria\resources\views/livewire/status-event.blade.php ENDPATH**/ ?>