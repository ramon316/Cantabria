<?php $__env->startSection('title', 'Eventos'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="container">
    <h1 class="text-center">Agregar descuentos</h1>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <h5 class="card-header">Agregar un descuento al evento</h5>
                <div class="card-body">
                    <?php if(is_null($discount)): ?>
                    <label for="">Ingresa la cantidad a descontar:</label>
                    <form action=" <?php echo e(route('discounts.store')); ?> " method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="number" class="form-control mb-2" name="amount" value="<?php echo e(old('amount')); ?>">
                        <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback d-block" role="alert"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <small id="helpId" class="form-text text-muted mb-2">Ingresa solo números, rango de $1.00 a $10,000.00</small>
                        <input type="hidden" value="<?php echo e($evento->id); ?>" name="evento">
                        <button type="submit" class="btn btn-primary">Guardar</button>
                    </form>
                    <?php else: ?>
                        Este evento ya cuenta con un descuento. Elimínalo si deseas agregar otra cantidad.
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <h5 class="card-header">Descuento agregados</h5>
                <div class="card-body">
                    <?php if(is_null($discount)): ?>
                    <p>Este evento aun no cuenta con descuento.</p>
                    <?php else: ?>
                    <p>El descuento que tiene el evento es de <strong>$ <?php echo number_format($discount->amount); ?></strong></p>
                    <?php endif; ?>
                </div>
                <?php if(is_null($discount)): ?>
                <div class="card-footer">

                </div>
                <?php else: ?>
                <div class="card-footer">
                    <form action="<?php echo e(route('discounts.destroy', ['discount' => $discount->id])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <input class="btn btn-danger" type="submit" value="Eliminar descuento">
                    </form>
                </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/discounts/create.blade.php ENDPATH**/ ?>