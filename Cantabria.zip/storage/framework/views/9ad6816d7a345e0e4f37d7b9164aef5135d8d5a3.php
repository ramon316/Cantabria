<div>

    <div class="row">
        <div class="col-md-3">
            <div class="form-group">
                <label for="cliente">Cliente</label> <?php echo e($cliente); ?>

                <select class="form-control" wire:model="cliente">
                    
                    <option value="">--Selecciona al cliente--</option>
                    <?php $__currentLoopData = $clientesAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cliente->id); ?>"> <?php echo e($cliente->nombre); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['cliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback" role="alert">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="col-md-3">
            <div class="form-group">
                <label for="evento">Selecciona el tipo:</label>
                <select class="form-control" wire:model="title">
                    <option value="">--Selecciona el tipo--</option>
                    <option value="Empresarial">Empresarial</option>
                    <option value="Social">Social</option>
                </select>
                <small id="helpNombre" class="form-text text-muted">Selecciona el tipo de evento que deseas
                    crear</small>
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback" role="alert">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="col-md-3">
            <div class="form-group">
                <label for="subtype">Selecciona el subtipo:</label>
                <select class="form-control" wire:model="subtitle">
                    
                    <option value="" selected>--Selecciona el subtipo--</option>
                    <?php $__currentLoopData = $subtitles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejemplo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($ejemplo); ?>"> <?php echo e($ejemplo); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback" role="alert">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label for="">Invitados</label>
                <input type="number" class="form-control" wire:model="invitados">
                <small id="helpId" class="form-text text-muted">Ingresa la cantidad de invitados para este
                    evento</small>
                <?php $__errorArgs = ['invitados'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback d-block" role="alert">
                    <?php echo e($message); ?>

                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>


    <div class="row">
        <div class="col-md-3">
            <div class="form-group">
                <label for="start">Fecha de inicio</label>
                <input type="datetime-local" class="form-control" wire:model="start">
                <small id="helpId" class="form-text text-muted">Ingresa la fecha de inicio del evento</small>
                <?php $__errorArgs = ['start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback d-block" role="alert">
                    <?php echo e($message); ?>

                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="col-md-3">
            <div class="form-group">
                <label for="end">Fecha de finalización</label>
                <input type="datetime-local" class="form-control" wire:model="end">
                <small id="helpId" class="form-text text-muted">Ingresa la fecha de finalización del evento</small>
                <?php $__errorArgs = ['end'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback d-block" role="alert">
                    <?php echo e($message); ?>

                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="form-group">
            <input type="button" class="btn btn-primary" value="Guardar" wire:click="save">
        </div>
    </div>

</div>
<?php /**PATH C:\laragon\www\Cantabria\resources\views/livewire/create-quoter.blade.php ENDPATH**/ ?>