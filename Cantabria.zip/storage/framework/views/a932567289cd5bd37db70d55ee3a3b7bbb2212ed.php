

<?php $__env->startSection('title', 'Eventos'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="container">
    <h1 class="text-center">Creación de evento</h1>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('create-event')->html();
} elseif ($_instance->childHasBeenRendered('fXcsiqe')) {
    $componentId = $_instance->getRenderedChildComponentId('fXcsiqe');
    $componentTag = $_instance->getRenderedChildComponentTagName('fXcsiqe');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fXcsiqe');
} else {
    $response = \Livewire\Livewire::mount('create-event');
    $html = $response->html();
    $_instance->logRenderedChild('fXcsiqe', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="/css/app.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/evento.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/eventos/create.blade.php ENDPATH**/ ?>