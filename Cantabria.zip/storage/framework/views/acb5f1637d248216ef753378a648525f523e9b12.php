<div class="mt-4">
    <div class="row">
        <div class="col-md-4">
            <label for="">Entrada/crema</label>
            <select name="" id="" class="form-control" wire:model.defer='entry'>
                <option value="">--Selecciona una entrada--</option>
                <?php $__currentLoopData = $entrys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($entry); ?>"><?php echo e($entry); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['entry'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="p-2 mt-2 text-xs text-danger">
                <?php echo e($message); ?>

            </div>  
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-4">
            <label>Plato fuerte a base de pollo</label>
            <select name="" id="" class="form-control" wire:model.defer='steak'>
                <option value="">--Selecciona una opción--</option>
                <?php $__currentLoopData = $steaks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $steak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($steak); ?>"><?php echo e($steak); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['steak'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="p-2 mt-2 text-xs text-danger">
                <?php echo e($message); ?>

            </div>  
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-4">
            <label>Salseo</label>
            <select name="" id="" class="form-control" wire:model.defer='sauce'>
                <option value="">--Selecciona una opción--</option>
                <?php $__currentLoopData = $sauces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sauce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($sauce); ?>"><?php echo e($sauce); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['sauce'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="p-2 mt-2 text-xs text-danger">
                <?php echo e($message); ?>

            </div>  
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="row">
        <div class="col-md-3 mt-4">
            <label for="">Guarnicion</label>
            <select name="" id="" class="form-control" wire:model.defer='fitting'>
                <option value="">--Selecciona una opción--</option>
                <?php $__currentLoopData = $fittings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fitting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($fitting); ?>"><?php echo e($fitting); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['fitting'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="p-2 mt-2 text-xs text-danger">
                <?php echo e($message); ?>

            </div>  
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

    
        
        <div class="col-md-3 mt-4">
            <label for="">2da Guarnicion</label>
            <select name="" id="" class="form-control" wire:model.defer='fitting2'>
                <option value="">--Selecciona una opción--</option>
                <?php $__currentLoopData = $fittings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fitting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($fitting); ?>"><?php echo e($fitting); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['fitting2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="p-2 mt-2 text-xs text-danger">
                <?php echo e($message); ?>

            </div>  
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>


        <div class="col-md-6 mt-4">
            <label for="">Notas:</label>
            <textarea name="" id="" cols="30" rows="3" class="form-control" wire:model.defer='notes'></textarea>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <a class="btn btn-primary mt-3" wire:click='saveBanquet'>Guardar banquete</a>
            <?php if($banquet): ?>
            <a class="btn btn-success mt-3" wire:click='format'>Formato</a>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\Cantabria\resources\views/livewire/banquet-index.blade.php ENDPATH**/ ?>