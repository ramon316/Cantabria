

<?php $__env->startSection('title', 'Perfil'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="text-center">Mi perfil</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <?php if(Auth::user()->perfil->imagen): ?>
                <img src="<?php echo e(asset('upload-perfiles') . '/' . Auth::user()->perfil->imagen); ?>">
            <?php else: ?>
                <img src="/upload-perfiles/default.png" class="img-fluid rounded mx-auto d-block" alt="">
            <?php endif; ?>
        </div>
        <div class="col-md-6 bg-white shadow mb-3 text-center">
            <p>
                <span class="font-weight-bold">Nombre: </span>
                <?php echo e($usuario->name); ?>

            </p>
            <p>
                <span class="font-weight-bold">Correo: </span>
                <?php echo e($usuario->email); ?>

            </p>
            <p>
                <span class="font-weight-bold">Rol: </span>
                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Administrador')): ?>
                Administrador
                <?php else: ?>
                Usuario
                <?php endif; ?>
            </p>
            <p>
                <span class="font-weight-bold">Teléfono: </span>
                <?php echo e($usuario->perfil->telefono); ?>

            </p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <a name="" id="" class="btn btn-warning" href="<?php echo e(route('perfils.edit', ['perfil'=>Auth::user()->id])); ?>" role="button">Editar</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/perfils/index.blade.php ENDPATH**/ ?>