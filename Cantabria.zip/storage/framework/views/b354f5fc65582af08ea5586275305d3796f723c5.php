<div>
    <div class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-10">
                    <input
                    type="search"
                    wire:model="search"
                    class="form-control"
                    placeholder="Ingresa el nombre de un cliente">
                </div>
                <div class="col-2">
                    <a class="btn btn-primary" href="" data-controls-modal="exampleModal"  data-toggle="modal" data-target="#exampleModal" data-bs-backdrop="static" data-bs-keyboard="false">Nuevo Comentario</a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Comentario</th>
                        <th>Fecha</th>
                        <th>Opciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $recommendations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommendation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($recommendation->name); ?></td>
                            <td><?php echo e($recommendation->comment); ?></td>
                            <td><?php echo e($recommendation->created_at->format('d/m/Y')); ?></td>
                            <td>
                                <svg class="mx-2" role="button" wire:click="$emit('delete',<?php echo e($recommendation->id); ?>)" xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 448 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M135.2 17.7L128 32H32C14.3 32 0 46.3 0 64S14.3 96 32 96H416c17.7 0 32-14.3 32-32s-14.3-32-32-32H320l-7.2-14.3C307.4 6.8 296.3 0 284.2 0H163.8c-12.1 0-23.2 6.8-28.6 17.7zM416 128H32L53.2 467c1.6 25.3 22.6 45 47.9 45H346.9c25.3 0 46.3-19.7 47.9-45L416 128z"/></svg>
                                
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="card-footer">
            <?php echo e($recommendations->links('pagination::bootstrap-4')); ?>

        </div>
        <!-- Modal -->
    <div class="modal fade" data-backdrop="static" data-keyboard="false" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true"  wire:ignore.self>
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Crear un nuevo comentario</h5>
            </div>
            <div class="modal-body">
                <div class="container">
                    <label for="">Ingresa el nombre</label>
                    <input type="text" class="form-control" placeholder="Ingresa el nombre" wire:model.defer='name'/>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-2" role="alert">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="">Ingresa su comentario</label>
                    <textarea name="" class="form-control" id="" rows="10" wire:model.defer='comment'></textarea>
                    <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-2" role="alert">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="">Ingresa su imagen de perfil</label>
                    <input 
                    type="file"
                    wire:model='image'
                    id='<?php echo e($identificador); ?>'
                    />
                    <?php if($image): ?>
                        <img width="300" class="m-2" src="<?php echo e($image->temporaryUrl()); ?>">
                    <?php endif; ?>
                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-2" role="alert">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal" >Cerrar</button>
              <button type="button" class="btn btn-primary" wire:click='save' wire:loading.attr = 'disabled' wire:target='save, image'>Guardar Comentario</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script>
        window.addEventListener('showModal', event =>{
            $("#exampleModal").modal('show');
        });
    
        window.addEventListener('closeModal', event => {
            console.log('entro');
            /* $("#exampleModal").modal('hide');   */              
        });
    </script>
</div>
<?php /**PATH C:\laragon\www\Cantabria\resources\views/livewire/recommendations.blade.php ENDPATH**/ ?>