

<?php $__env->startSection('title', 'Eventos'); ?>

<?php $__env->startSection('content_header'); ?>
<a  class="btn btn-success btn-sm" href="<?php echo e(route('cotizacion.index')); ?>">Regresar</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('quoter-create', ['cotizacion' => $cotizacion])->html();
} elseif ($_instance->childHasBeenRendered('vKHol2F')) {
    $componentId = $_instance->getRenderedChildComponentId('vKHol2F');
    $componentTag = $_instance->getRenderedChildComponentTagName('vKHol2F');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vKHol2F');
} else {
    $response = \Livewire\Livewire::mount('quoter-create', ['cotizacion' => $cotizacion]);
    $html = $response->html();
    $_instance->logRenderedChild('vKHol2F', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/cotizacion/show.blade.php ENDPATH**/ ?>