

<?php $__env->startSection('title', 'Inventario manteles'); ?>

<?php $__env->startSection('plugins.Sweetalert2', true); ?>

<?php $__env->startSection('content_header'); ?>
<h1 class="text-center">Inventario de bases de manteles</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('inventories.tableclothbase-index')->html();
} elseif ($_instance->childHasBeenRendered('wqZQSpb')) {
    $componentId = $_instance->getRenderedChildComponentId('wqZQSpb');
    $componentTag = $_instance->getRenderedChildComponentTagName('wqZQSpb');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wqZQSpb');
} else {
    $response = \Livewire\Livewire::mount('inventories.tableclothbase-index');
    $html = $response->html();
    $_instance->logRenderedChild('wqZQSpb', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    Livewire.on('mostrarAlerta',tableclothbaseId =>{
        Swal.fire({
            title: 'Estas seguro de eliminar el registro?',
            text: "No podrás recuperarlo",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Si, eliminalo!'
            })
            .then((result) => {
            if (result.value== true) {
                Swal.fire(
                    'Registro eliminado!',
                    Livewire.emit('delete', tableclothbaseId)
                )
            }
        })
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/tableclothbase/index.blade.php ENDPATH**/ ?>