

<?php $__env->startSection('title', 'Eventos'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="container-fluid">
    <div class="row m-3 ">
      <div class="col-md-1">
        <a  class="btn btn-success" href="<?php echo e(route('inventory.tablecloth')); ?>">Regresar</a>
      </div>
      <div class="col-md-11">
        <h1 class="text-center">Crear un nuevo mantel</h1>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
    <form action="<?php echo e(route('inventory.tableclothstore')); ?>" method="post" enctype="multipart/form-data" novalidate>
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
        <div class="row">
         <div class="col-md-4">
             <label for="">Nombre del mantel</label>
             <input type="text"
             name="name"
             class="form-control"
             value="<?php echo e(old('name')); ?>"
             >
             <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback d-block" role="alert"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
         </div>
         <div class="col-md-4">
             <label for="">Tonalidad del mantel</label>
             <input type="text"
             name="tonality"
             class="form-control"
             value="<?php echo e(old('tonality')); ?>">
         </div>
         <div class="col-md-4">
             <label for="">Tipo de mesa</label>
             <select class="form-control" name="tabletype">
                 <option value="">--Selecciona un tipo de mesa--</option>
                 <option value="Cuadrada" 
                 <?php echo e(old('status')=='Cuadrada' ? 'selected' : ''); ?>>
                 Cuadrada</option>
                 <option value="Imperial" 
                 <?php echo e(old('status')=='Imperial' ? 'selected' : ''); ?>>
                Imperial</option>
                 <option value="Redonda" 
                 <?php echo e(old('status')=='Redonda' ? 'selected' : ''); ?>>
                    Redonda</option>
             </select>
         </div>
        </div>
        <div class="row">
             <div class="col-md-4">
                 <label for="">Estado de los manteles</label>
                 <select class="form-control" name="status">
                     <option value="">--Selecciona una opción</option>
                     <option value="Bueno"
                     <?php echo e(old('status')=='Bueno' ? 'selected' : ''); ?>>
                     Bueno</option>
                     <option value="Regular"
                     <?php echo e(old('status')=='Regular' ? 'selected' : ''); ?>>
                     Regular</option>
                     <option value="Malo" 
                     <?php echo e(old('status')=='Malo' ? 'selected' : ''); ?>>
                        Malo</option>
                 </select>
             </div>
             <div class="col-md-3">
                 <label for="">Cantidad de manteles</label>
                 <input type="number"
                 class="form-control"
                 name="amount"
                 value="<?php echo e(old('amount')); ?>">
                 <small class="form-text text-muted">Ingresa la cantidad de manteles</small>
             </div>
        </div>
        <div class="row">
             <div class="col-md-4">
                 <label for="">Selecciona la imagen del mantel</label>
                 <input type="file" type="hidden" value="<?php echo e(old('image')); ?>" name="image" id="">
             </div>
        </div>
        <div class="row">
            <div class="col-md-3">
                <input type="submit" class="btn btn-primary mt-3" value="Guardar">
            </div>
        </div>
    </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/inventories/tableclothcreate.blade.php ENDPATH**/ ?>