

<?php $__env->startSection('title', 'Reportes'); ?>

<?php $__env->startSection('plugins.Chartjs', true); ?>


<?php $__env->startSection('content_header'); ?>
<h1 class="text-center">Reportes</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    
    <div class="row bg-white shadow">
        <div class="col-md-6">
            <?php echo $chartMonths->renderHtml(); ?>

        </div>
        <div class="col-md-6">
            <?php echo $chartTitle->renderHtml(); ?>

        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php echo $chartMonths->renderChartJsLibrary(); ?>

<?php echo $chartMonths->renderJs(); ?>

<?php echo $chartTitle->renderJs(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/reports/index.blade.php ENDPATH**/ ?>