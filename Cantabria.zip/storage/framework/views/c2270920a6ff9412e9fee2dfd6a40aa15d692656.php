<!--Plantilla AdminLTE-->


<?php $__env->startSection('title', 'Usuarios'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="container">
    <h1 class="text-center">Modificar Usuario</h1>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('mensaje')): ?>
<div class="alert <?php echo e(session('estilo')); ?> alert-dismissible fade show" role="alert">
    <strong><?php echo e(session('mensaje')); ?></strong> 
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php endif; ?>
<div class="card">
    <div class="card-body">
        <p class="h5">Nombre</p>
        <p class="form-control"><?php echo e($usuario->name); ?></p>
        
        <p class="h5">Listado de Roles</p>
        <?php echo Form::model($usuario, ['route' => ['usuarios.update', $usuario], 'method' => 'put']); ?>

            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>   
                    <label>
                        <?php echo Form::checkbox('roles[]', $role->id, null, ['class' => 'mr-1' ]); ?> 
                        <?php echo e($role->name); ?>

                    </label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo Form::submit('Asignar Rol', ['class' => 'btn btn-primary']); ?>

        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<link rel="stylesheet" href="/css/app.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/usuarios/edit.blade.php ENDPATH**/ ?>