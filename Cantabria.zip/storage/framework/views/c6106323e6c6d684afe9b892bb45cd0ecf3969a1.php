<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8" />
        
        <!-- Styles -->
        <style>
            
            body{
                background-size: cover;
                background-repeat: no-repeat;
                margin: 0;
                height: 100vh;
                background-image: url(<?php echo e(public_path('image/banquete.png')); ?>);
                background-size: 100%;
                background-position: center center;
            }
            .informacion{
                margin-top: 50px;
                margin-left: 30px;
                margin-right: 20px;
            }
            .card-header{
                text-align: center;
                font-weight: 700;
                font-size: 20px;
                color: black;
                background-color: transparent;
            }
            .card-footer{
                margin-top: 50px;
            }
            label{
                padding-top: 20px;
                font-weight: 700;
            }

        </style>
        <title>Formato de banquete</title>

    </head>
<body>
<div class="informacion">
    <div class="card-header">
        Detalles del Banquete
    </div>
    <div class="card-body">
        <p>Hola <strong><?php echo e($evento->cliente->nombre); ?>!</strong>, Te comparto la elección de platillo que hicieron en su degustación:
        </p>
    </div>
    <div class="information">
        <label>Entrada:</label> <?php echo e($banquet->entry); ?><br>
        <label>Plato fuerte:</label> <?php echo e($banquet->steak); ?><br>
        <label>Salseo:</label> <?php echo e($banquet->sauce); ?><br>
        <label>Guarnición:</label> <?php echo e($banquet->fitting); ?><br>
        <?php if($banquet->fitting2): ?>
        <label>Guarnición 2:</label> <?php echo e($banquet->fitting2); ?><br>
        <?php endif; ?>
        <?php if($banquet->notes): ?>
        <label>Notas:</label> <?php echo e($banquet->notes); ?></p>
        <?php endif; ?>
    </div>
    <div  class="card-footer">
        ¡Espero que hayan disfrutado de la experiencia! Si tienen alguna pregunta o comentario, no duden en hacérmelo saber. Gracias por su confianza.
    </div>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\Cantabria\resources\views/banquets/format.blade.php ENDPATH**/ ?>