<div>
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h3>Mantelería</h3>
                <div class="row">
                    
                    <div class="col-md-2 mt-1">
                        <select class="form-control" wire:model="type">
                            <option value="">--Tipo de mesa--</option>
                           <?php $__currentLoopData = $tabletypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <option value="<?php echo e($tipo->tabletype); ?>"><?php echo e($tipo->tabletype); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="p-2 mt-2 text-xs text-danger">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="col-md-2 mt-1">
                        <select class="form-control" wire:model="name">
                            <?php if($tablenames->count()==0): ?>
                            <option value="">--Sin valores--</option>
                            <?php else: ?>
                                <option value="">--Nombre del mantel--</option>
                                <?php $__currentLoopData = $tablenames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tablename): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tablename->name); ?>"><?php echo e($tablename->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="p-2 mt-2 text-xs text-danger">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="col-md-2 mt-1">
                        <select class="form-control" wire:model="color">
                        <?php if($tablecolors->count() == 0 or $tablenames->count() == 0): ?>
                            <option>--Sin valores--</option>
                        <?php else: ?>
                            <option value="">--Tonalidad de mantel--</option>
                            <?php $__currentLoopData = $tablecolors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tablecolor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tablecolor->tonality); ?>"><?php echo e($tablecolor->tonality); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </select>
                        <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="p-2 mt-2 text-xs text-danger">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="col-md-2 mt-1">
                        <select class="form-control" wire:model="colorbase">
                        <?php if($tablecolorbases->count() == 0 or $tablenames->count() == 0 or $tabletypes->count()==0): ?>
                            <option>--Sin valores--</option>
                        <?php else: ?>
                            <option value="">--Color de base--</option>
                            <?php $__currentLoopData = $tablecolorbases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tablecolorbase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tablecolorbase->color); ?>"><?php echo e($tablecolorbase->color); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </select>
                        <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="p-2 mt-2 text-xs text-danger">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="col-md-2 mt-1">
                        <select class="form-control" wire:model='chairtype'>
                            <?php if($chairtypes->count() == 0): ?>
                                <option value="">--Sin valores--</option>
                            <?php else: ?>
                            <option value="">--Tipo silla--</option>
                                <?php $__currentLoopData = $chairtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chairtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($chairtype->typechair); ?>"><?php echo e($chairtype->typechair); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <?php $__errorArgs = ['chairtype'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="p-2 mt-2 text-xs text-danger">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="col-md-2 mt-1">
                        <select class="form-control" wire:model='chaircolor'>
                            <?php if($chaircolors->count() == 0): ?>
                                <option value="">--Sin valor--</option>
                            <?php else: ?>
                            <option value="">--Color silla--</option>
                            <?php $__currentLoopData = $chaircolors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chaircolor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($chaircolor->color); ?>"><?php echo e($chaircolor->color); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <?php $__errorArgs = ['chaircolor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="p-2 mt-2 text-xs text-danger">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-2 mt-1">
                        <input class="form-control" type="number" placeholder="Cantidad de mesas" wire:model='amount'>
                        <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="p-2 mt-2 text-xs text-danger">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-2 mt-1">
                        <input class="form-control" type="number" placeholder="Cantidad de sillas" wire:model='chairs'>
                        <?php $__errorArgs = ['chairs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="p-2 mt-2 text-xs text-danger">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col text-right mt-1">
                        <button class="btn btn-primary" wire:click='addTablecloth'>Agregar</button>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php if(count($records) >= 1): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Tipo mesa</th>
                            <th>Mantel</th>
                            <th>Tonalidad</th>
                            <th>Base</th>
                            <th>Tipo Silla</th>
                            <th>Color</th>
                            <th>Número de mesas</th>
                            <th>Número de sillas</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($record->tabletype); ?></td>
                            <td><?php echo e($record->name); ?></td>
                            <td><?php echo e($record->tonality); ?></td>
                            <td><?php echo e($record->color); ?></td>
                            <td><?php echo e($record->typechair); ?></td>
                            <td><?php echo e($record->chaircolor); ?></td>
                            <td><?php echo e($record->amount); ?></td>
                            <td><?php echo e($record->chairs); ?></td>
                            <td><a class="btn btn-danger" wire:click="deleteTablecloth(<?php echo e($record->id); ?>)">Eliminar</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php else: ?>
                    Este evento aun no cuenta con mantelería registrada.
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\Cantabria\resources\views/livewire/add-tablecloth.blade.php ENDPATH**/ ?>