<div>
    
    <div class="row">
        <div class="col-md-5">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><?php echo e($cliente->nombre); ?></h3>
                    <h6> - <?php echo e($cotizacion->start->format('d-m-Y')); ?></h6>
                    <h6><?php echo e($cotizacion->title); ?> - <?php echo e($cotizacion->subtitle); ?></h6>
                </div>
                <div class="card-body">
                    <h6>Servicios agregados</h6>
                    <table class="table table-bordered table-hover">
                        <tbody class="text-center">
                        <?php if($quoterServices->isEmpty()): ?>
                            <p class="text-secondary">Este evento aun no cuenta con servicios agregados</p>
                        <?php else: ?>
                            <tr class="expandable-body">
                                <th>Servicio</th>
                                <th>Cantidad</th>
                                <th>Costo ind.</th>
                                <th>Regalo</th>
                                <th>Eliminar</th>
                            </tr>
                            <?php $__currentLoopData = $quoterServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td scope="row"><?php echo e($service->nombre); ?></td>
                                <td><?php echo e($service->pivot->cantidad); ?></td>
                                <td>$<?php echo number_format($service->pivot->costo  * $service->pivot->cantidad); ?> </td>
                                <td>
                                    <?php if($service->pivot->regalo): ?>
                                    Si
                                    <?php else: ?>
                                    No
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <i class="fas fa-trash" role="button"
                                        wire:click="deleteService(<?php echo e($service->id); ?>)"></i>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer">
                    <h3>Inversión del Evento: $<?php echo number_format($costQuoter); ?></h3>
                    <a href="<?php echo e(route('cotizacion.cotizacion', ['cotizacion' => $cotizacion->id])); ?>}" class="btn btn-primary">Generar Cotización</a>
                </div>
            </div>
        </div>
        <div class="col-md-7">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <div class="input-group">
                            <span class="input-group-text" id="basic-addon1">Buscar:</span>
                            <input type="text" class="form-control" placeholder="Nombre del servicio"
                                aria-label="Username" aria-describedby="basic-addon1" wire:model="search">
                        </div>
                    </h3>
                    
                    <!-- /.card-tools -->
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <table class="table table-bordered table-hover">
                        <tbody class="text-center">
                            <tr class="expandable-body">
                                <th>Nombre</th>
                                <th>Precio</th>
                                <th>Agregar</th>
                            </tr>
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr data-widget="expandable-table" aria-expanded="false">
                                <td><?php echo e($service->nombre); ?></td>
                                <td>$<?php echo number_format($service->costo); ?></td>
                                <td class="text-center">
                                    <i class="fas fa-plus-circle" role="button" data-controls-modal="exampleModal"
                                        data-toggle="modal" data-target="#exampleModal" data-bs-backdrop="static"
                                        data-bs-keyboard="false" wire:click="Addservice(<?php echo e($service->id); ?>)"></i>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                    <?php echo e($services->links()); ?>

                </div>
            </div>
        </div>
    </div>
    <!-- Button trigger modal -->
    <div class="modal fade" data-backdrop="static" data-keyboard="false" id="exampleModal" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalLabel" aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Agregar servicio</h5>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <span class=""><?php echo e($servicioName); ?></span>
                        <div class="row">
                            <div class="col">
                                <input class="form-control mt-2" type="number" wire:model="count">
                            </div>
                            <div class="col">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" wire:model="gift">
                                    <label class="form-check-label">
                                        Servicio de regalo
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"
                        wire:click='close'>Cerrar</button>
                    <button type="button" class="btn btn-primary"
                        wire:click="save(<?php echo e($count); ?>,'<?php echo e($servicioName); ?>', '<?php echo e($gift); ?>')">Guardar</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    window.addEventListener('showModal', event =>{
            $("#exampleModal").modal('show');
        });

    /* Cerrar modal */
    window.addEventListener('closeModal', event=>{
        $('#exampleModal').modal('hide');
    })


</script>
</div>
<?php /**PATH C:\laragon\www\Cantabria\resources\views/livewire/quoter-create.blade.php ENDPATH**/ ?>