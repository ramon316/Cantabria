

<?php $__env->startSection('title', 'Reuniones'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="text-center">Retroalimentación de la Reunión</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h3 for=""><?php echo e($meet->reason->reason); ?> para <?php echo e($meet->user->name); ?></h3>
                <h3 class="card-title">Reunión con el cliente <?php echo e($meet->cliente->nombre); ?> el día
                    <?php echo e($meet->start->format('d-m-Y H:i a')); ?></h3>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('meets.update', ['meet' => $meet])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row">
                        <div class="col-md-3">
                            <label for="">Resultado de la reunión</label>
                            <select name="contrato" id="" class="form-control">
                                <option value="" <?php if(is_null($meet->contrato)): ?> selected                             
                                <?php endif; ?>>--Selecciona una opción--</option>
                                <option value="1" <?php if($meet->contrato === 1): ?> selected <?php endif; ?>>
                                    Si contrato</option>
                                <option value="0" <?php if($meet->contrato === 0): ?> selected <?php endif; ?>>
                                    No contrato</option>>No contrato</option>
                            </select>
                            <?php $__errorArgs = ['contrato'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback d-block" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-8">
                            <label for="">Observaciones</label>
                            <textarea name="observacion" id="" class="form-control"><?php echo e($meet->observacion); ?></textarea>
                            <?php $__errorArgs = ['observacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback d-block" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <button class="btn btn-primary">Guardar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/meets/show.blade.php ENDPATH**/ ?>