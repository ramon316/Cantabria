<?php $__env->startSection('title', 'Bases florales'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="container-fluid">
    <div class="row m-3 ">
      <div class="col-md-1">
        <a  class="btn btn-success" href="<?php echo e(route('eventos.show',['evento'=>$evento->id])); ?>">Regresar</a>
      </div>
      <div class="col-md-11">
        <h1 class="text-center">Bases florales del evento</h1>
      </div>
    </div>
</div>
<div class="container">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-evento-floralbase', ['evento' => $evento])->html();
} elseif ($_instance->childHasBeenRendered('9hQnmq3')) {
    $componentId = $_instance->getRenderedChildComponentId('9hQnmq3');
    $componentTag = $_instance->getRenderedChildComponentTagName('9hQnmq3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9hQnmq3');
} else {
    $response = \Livewire\Livewire::mount('add-evento-floralbase', ['evento' => $evento]);
    $html = $response->html();
    $_instance->logRenderedChild('9hQnmq3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('comments-index', ['evento' => $evento])->html();
} elseif ($_instance->childHasBeenRendered('F8MAXxy')) {
    $componentId = $_instance->getRenderedChildComponentId('F8MAXxy');
    $componentTag = $_instance->getRenderedChildComponentTagName('F8MAXxy');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('F8MAXxy');
} else {
    $response = \Livewire\Livewire::mount('comments-index', ['evento' => $evento]);
    $html = $response->html();
    $_instance->logRenderedChild('F8MAXxy', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/basefloral/create.blade.php ENDPATH**/ ?>