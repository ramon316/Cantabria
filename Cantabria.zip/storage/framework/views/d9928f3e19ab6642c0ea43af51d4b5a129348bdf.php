<div>
    <div class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-10">
                    <input
                    type="search"
                    wire:model="search"
                    class="form-control"
                    placeholder="Ingresa el nombre del servicio">
                </div>
                <div class="col-2">
                    <a class="btn btn-primary" href=" <?php echo e(route('servicios.create')); ?>">Nuevo Servicio</a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Costo</th>
                        <th>Invitados</th>
                        <th>Descripción</th>
                        <th>Categoría</th>
                        <th>Días</th>
                        <th>Año</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($service->nombre); ?></td>
                            <td>$<?php echo number_format($service->costo); ?></td>
                            <td><?php echo e($service->invitados); ?></td>
                            <td><?php echo e($service->descripcion); ?></td>
                            <td><?php echo e($service->categoria); ?></td>
                            <td>
                                <?php if($service->dias == 1): ?>
                                    Fin de semana
                                <?php else: ?>
                                    Entre semana
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($service->año); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="card-footer">
            <?php echo e($services->links('pagination::bootstrap-4')); ?>

        </div>
    </div>
</div>

<?php /**PATH C:\laragon\www\Cantabria\resources\views/livewire/services-index.blade.php ENDPATH**/ ?>