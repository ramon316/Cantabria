

<?php $__env->startSection('title', 'Pagos'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="container-fluid">
    <div class="row m-3 ">
      <div class="col-md-1">
        <a  class="btn btn-success" href="<?php echo e(route('eventos.show',['evento'=>$evento->id])); ?>">Regresar</a>
      </div>
      <div class="col-md-11">
        <h1 class="text-center">Captura de pagos</h1>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="app">
    <div class="container">
        <div class="row justify-content-around">
            <div class="col-md-4 bg-white p-2 mb-3 shadow">
                <label>Cliente: <?php echo e($evento->cliente->nombre); ?></label><br>
                <label>Número de evento: <?php echo e($evento->id); ?></label><br>
                <label>Tipo del evento: <?php echo e($evento->title); ?></label><br>
                <label>Fecha: <?php echo e($evento->start->format('d-m-Y')); ?></label>
            </div>
            <div class="col-md-4 shadow-lg bg-white p-2 mb-3">
                <label for="">Costo del evento: <?php echo number_format($costoEvento); ?></label><br>
                <label for="">Cantidad pagada del evento: $ <?php echo number_format($pagado); ?></label>
            </div>
        </div>
        <form method="POST" action="<?php echo e(route('pagos.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="row">

                <div class="col-md-4">
                    <div class="form-group">
                        <label for="tipo">Tipo de Pago:</label>
                        <select class="form-control 
                        <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            is-invalid
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tipo" id="tipo">
                        <option value="">--Tipo--</option>
                        <option value="abono">Abono</option>
                        <option value="anticipo">Anticipo</option>
                        <option value="liquidacion">Liquidación</option>
                        </select>
                        <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback d-block" role="alert"> <?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                    <label for="">Monto</label>
                    <input type="number"
                        class="form-control 
                        <?php $__errorArgs = ['monto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            is-invalid
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                        name="monto" id="monto" aria-describedby="helpId" placeholder=""
                        value="<?php echo e(old('monto')); ?>">
                        <?php $__errorArgs = ['monto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback d-block" role="alert"> <?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <small id="helpId" class="form-text text-muted">Ingresa el monto del abono al avento</small>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                      <label for="cuenta">Cuenta</label>
                      <select class="form-control
                      <?php $__errorArgs = ['cuenta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        is-invalid
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cuenta" id="cuenta">
                        <option value="">--Cuenta--</option>
                        <?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cuenta->id); ?>"><?php echo e($cuenta->cuenta); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      <?php $__errorArgs = ['cuenta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback d-block" role="alert"> <?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <input type="hidden"
                name="evento" id="evento" 
                value="<?php echo e($evento->id); ?>">

                <input type="hidden"
                name="cliente" id="cliente" 
                value="<?php echo e($evento->cliente_id); ?>">


                <div class="col-md-4">
                    <div class="form-group">
                      <input type="submit" class="btn btn-primary" alig value="Guardar">
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/pagos/index.blade.php ENDPATH**/ ?>