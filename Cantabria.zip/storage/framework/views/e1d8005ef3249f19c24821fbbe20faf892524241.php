<div>
    <div class="card">
        <div class="card-body">
            <div class="card-header">
                <div class="row">
                    <div class="col-10">
                        <input type="search" class="form-control" placeholder="Ingresa el nombre del cliente" wire:model='search'>
                    </div>
                    <div class="col-2">
                        <a class="btn btn-primary" href=" <?php echo e(route('cotizacion.create')); ?>">Nueva cotización</a>
                    </div>
                </div>
            </div>
            <?php if($cotizaciones->count()): ?>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Cliente</th>
                        <th>Fecha del evento</th>
                        <th>Fecha de cotización</th>
                        <th>Validez</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $cotizaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cotizacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($cotizacion->nombre); ?></td>
                        <td><?php echo e(date('d-m-Y', strtotime($cotizacion->start))); ?></td>
                        <td><?php echo e(date('d-m-Y', strtotime($cotizacion->created_at))); ?></td>
                        <td><?php if($cotizacion->validez >= $hoy): ?>
                            <button class="btn btn-success" href="">Activa</button>
                            <?php else: ?>
                            <button class="btn btn-danger" href="">Caducada</button>
                            <?php endif; ?>
                        </td>
                        <td width="10px">
                            <a class="btn btn-primary"
                                href="<?php echo e(route('cotizacion.show', ['cotizacion' => $cotizacion->id])); ?>">Ver</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php else: ?>
                <div class="card-body">
                    <label for="">No tienes ninguna cotización aun. Puedes crearla en el boton superior</label>
                </div>
            <?php endif; ?>
        </div>

        <div class="card-footer">
            <?php echo e($cotizaciones->links('pagination::bootstrap-4')); ?>

        </div>
    </div>
</div><?php /**PATH C:\laragon\www\Cantabria\resources\views/livewire/cotizacion-index.blade.php ENDPATH**/ ?>