<div>
    <div>
        <div class="card">
            <div class="card-header">
                <div class="row d-flex justify-content-start">
                    <div class="col-6">
                        <input type="search" wire:model='search' placeholder="Ingresa el nombre del cliente"
                            class="form-control">
                    </div>
                    <div class="col-2">
                        <input type="datetime-local" name="" id="" class="form-control"
                            wire:model="inicio">
                        <p class="text-center font-weight-light">Fecha inicial</p>
                    </div>
                    <div class="col-2">
                        <input type="datetime-local" name="" id="" class="form-control"
                            wire:model="fin">
                        <p class="text-center font-weight-light">Fecha final</p>
                    </div>
                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Administrador')): ?>
                        <div class="col-2">
                            <a class="btn btn-primary" href=" <?php echo e(route('meets.create')); ?>">Crear Reunión</a>
                        </div>
                    <?php endif; ?>
                </div>

            </div>
            <div class="card-body">
                <?php if($meets->isEmpty()): ?>
                    No cuentas con reuniones asiganadas.
                <?php else: ?>
                    <table class="table table-striped text-center">
                        <thead>
                            <tr>
                                <th>Vendedor</th>
                                <th>Cliente</th>
                                <th>Fecha</th>
                                <th>Motivo</th>
                                <th>Contrato</th>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eventos.show')): ?>
                                    <th>Opciones</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $meets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($meet->user->name); ?></td>
                                    <td><?php echo e($meet->nombre); ?></td>
                                    <td><?php echo e(date('d-m-Y H:i', strtotime($meet->start))); ?></td>
                                    <td><?php echo e($meet->reason->reason); ?></td>
                                    <td>
                                        <?php if(!is_Null($meet->contrato)): ?>
                                            <?php if($meet->contrato == 1): ?>
                                                <button class="btn btn-success btn-sm">Si</button>
                                           <?php else: ?>
                                                <button class="btn btn-danger btn-sm">No</button>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eventos.show')): ?>
                                            <a class="btn btn-primary"
                                                href="<?php echo e(route('meets.show', ['meet' => $meet->id])); ?>">Ver</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <div class="card-footer">
                <?php echo e($meets->links('pagination::bootstrap-4')); ?>

            </div>
        </div>
    </div>

</div>
<?php /**PATH C:\laragon\www\Cantabria\resources\views/livewire/create-meet.blade.php ENDPATH**/ ?>