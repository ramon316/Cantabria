<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<img src="https://cantabriaeventos.com/image/logo.jpeg" class="logo" alt="Laravel Logo">
</a>
</td>
</tr>
<?php /**PATH C:\laragon\www\Cantabria\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>