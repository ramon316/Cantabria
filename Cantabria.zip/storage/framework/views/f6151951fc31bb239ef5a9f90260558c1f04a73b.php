

<?php $__env->startSection('title', 'Manteleria'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="container-fluid">
    <div class="row m-3 ">
      <div class="col-md-1">
        <a  class="btn btn-success" href="<?php echo e(route('eventos.show',['evento'=>$evento->id])); ?>">Regresar</a>
      </div>
      <div class="col-md-11">
        <h1 class="text-center">Guardar Mantelería del evento</h1>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-tablecloth',['evento'=>$evento])->html();
} elseif ($_instance->childHasBeenRendered('MdaH5KH')) {
    $componentId = $_instance->getRenderedChildComponentId('MdaH5KH');
    $componentTag = $_instance->getRenderedChildComponentTagName('MdaH5KH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('MdaH5KH');
} else {
    $response = \Livewire\Livewire::mount('add-tablecloth',['evento'=>$evento]);
    $html = $response->html();
    $_instance->logRenderedChild('MdaH5KH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/manteleria/create.blade.php ENDPATH**/ ?>