<?php $__env->startSection('title', 'Servicios'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="container">
    <div class="container-fluid">
        <div class="row m-3 ">
          <div class="col-md-1">
            <a  class="btn btn-secondary" href="<?php echo e(route('eventos.show',['evento'=>$evento->id])); ?>">Regresar</a>
          </div>
          <div class="col-md-11">
            <h1 class="text-center">Agregar servicio al evento</h1>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-service', ['evento' => $evento])->html();
} elseif ($_instance->childHasBeenRendered('IEnFoBH')) {
    $componentId = $_instance->getRenderedChildComponentId('IEnFoBH');
    $componentTag = $_instance->getRenderedChildComponentTagName('IEnFoBH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('IEnFoBH');
} else {
    $response = \Livewire\Livewire::mount('add-service', ['evento' => $evento]);
    $html = $response->html();
    $_instance->logRenderedChild('IEnFoBH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="/css/app.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cantabria\resources\views/eventoservicios/create.blade.php ENDPATH**/ ?>